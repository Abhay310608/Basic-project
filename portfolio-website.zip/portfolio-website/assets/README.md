Put your files here:

- `resume.pdf`: your résumé (linked from the hero button)
- optional: a profile photo, project screenshots

Then reference them from `index.html` or `js/data.js`.
