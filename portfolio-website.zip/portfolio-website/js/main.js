(function () {
  "use strict";
  const data = window.PORTFOLIO || { skills: [], projects: [], timeline: [] };
  const $ = (sel) => document.querySelector(sel);

  /* ---------- helpers ---------- */
  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  /* ---------- theme toggle ---------- */
  const root = document.documentElement;
  $("#theme-toggle").addEventListener("click", () => {
    const current =
      root.getAttribute("data-theme") ||
      (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
    const next = current === "dark" ? "light" : "dark";
    root.setAttribute("data-theme", next);
    try { localStorage.setItem("theme", next); } catch (e) {}
  });

  /* ---------- mobile nav ---------- */
  const nav = $("#nav");
  const navToggle = $("#nav-toggle");
  function setNav(open) {
    nav.classList.toggle("open", open);
    navToggle.setAttribute("aria-expanded", String(open));
  }
  navToggle.addEventListener("click", () => setNav(!nav.classList.contains("open")));
  nav.addEventListener("click", (e) => { if (e.target.tagName === "A") setNav(false); });

  /* ---------- skills ---------- */
  const skillsGrid = $("#skills-grid");
  data.skills.forEach((g) => {
    const card = el("div", "skill-card reveal");
    card.appendChild(el("h3", "", g.group));
    const list = el("ul", "chips");
    g.items.forEach((s) => list.appendChild(el("li", "", s)));
    card.appendChild(list);
    skillsGrid.appendChild(card);
  });

  /* ---------- projects + filters ---------- */
  const grid = $("#projects-grid");
  const filters = $("#filters");
  const tags = ["All", ...new Set(data.projects.flatMap((p) => p.tags))];
  let activeTag = "All";

  function renderFilters() {
    filters.textContent = "";
    tags.forEach((tag) => {
      const b = el("button", "filter-btn" + (tag === activeTag ? " active" : ""), tag);
      b.type = "button";
      b.setAttribute("aria-pressed", String(tag === activeTag));
      b.addEventListener("click", () => { activeTag = tag; renderFilters(); renderProjects(); });
      filters.appendChild(b);
    });
  }

  function linkBtn(label, href) {
    const a = el("a", "card-link", label);
    a.href = href;
    a.target = "_blank";
    a.rel = "noopener";
    return a;
  }

  function renderProjects() {
    grid.textContent = "";
    data.projects
      .filter((p) => activeTag === "All" || p.tags.includes(activeTag))
      .forEach((p) => {
        const card = el("article", "project-card reveal visible");
        card.appendChild(el("h3", "", p.title));
        card.appendChild(el("p", "", p.description));
        const stack = el("ul", "chips small");
        p.stack.forEach((s) => stack.appendChild(el("li", "", s)));
        card.appendChild(stack);
        const links = el("div", "card-links");
        if (p.repo) links.appendChild(linkBtn("Code", p.repo));
        if (p.demo) links.appendChild(linkBtn("Live demo", p.demo));
        if (links.children.length) card.appendChild(links);
        grid.appendChild(card);
      });
  }
  renderFilters();
  renderProjects();

  /* ---------- timeline ---------- */
  const timeline = $("#timeline");
  data.timeline.forEach((t) => {
    const li = el("li", "timeline-item reveal");
    li.appendChild(el("span", "period", t.period));
    li.appendChild(el("h3", "", t.title));
    li.appendChild(el("p", "", t.text));
    timeline.appendChild(li);
  });

  /* ---------- contact form (opens visitor's email client) ---------- */
  const form = $("#contact-form");
  const status = $("#cf-status");
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = $("#cf-name").value.trim();
    const email = $("#cf-email").value.trim();
    const message = $("#cf-message").value.trim();
    if (!name || !message || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
      status.textContent = "Please fill in all fields with a valid email address.";
      status.className = "form-status error";
      return;
    }
    const subject = encodeURIComponent("Portfolio message from " + name);
    const body = encodeURIComponent(message + "\n\n" + name + " (" + email + ")");
    window.location.href = "mailto:" + data.contactEmail + "?subject=" + subject + "&body=" + body;
    status.textContent = "Opening your email app...";
    status.className = "form-status ok";
  });

  /* ---------- scroll reveal ---------- */
  if ("IntersectionObserver" in window) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (en.isIntersecting) { en.target.classList.add("visible"); io.unobserve(en.target); }
      });
    }, { threshold: 0.12 });
    document.querySelectorAll(".reveal:not(.visible)").forEach((n) => io.observe(n));
  } else {
    document.querySelectorAll(".reveal").forEach((n) => n.classList.add("visible"));
  }

  $("#year").textContent = new Date().getFullYear();
})();
