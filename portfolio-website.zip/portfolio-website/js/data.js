/* =========================================================
   EDIT THIS FILE to customize your portfolio content.
   No HTML changes are needed for skills, projects or timeline.
   ========================================================= */

window.PORTFOLIO = {
  // Email that the contact form opens in the visitor's mail app
  contactEmail: "you@example.com",

  skills: [
    { group: "Languages", items: ["Python", "JavaScript", "SQL", "Java"] },
    { group: "Testing", items: ["pytest", "Playwright", "Selenium", "Postman", "API testing"] },
    { group: "Web", items: ["HTML5", "CSS3", "React", "REST APIs"] },
    { group: "Tools", items: ["Git & GitHub", "GitHub Actions (CI/CD)", "Docker", "Jira", "Linux"] }
  ],

  // tags drive the filter buttons automatically
  projects: [
    {
      title: "QA Automation Framework",
      description: "UI and API test framework using Playwright and pytest with Page Object Model, HTML reports and a CI pipeline.",
      tags: ["Testing", "Python"],
      stack: ["Python", "Playwright", "pytest", "GitHub Actions"],
      repo: "https://github.com/your-username/qa-automation-framework",
      demo: ""
    },
    {
      title: "Software Testing Demo",
      description: "Beginner-friendly unit-testing project with fixtures, parametrized tests and coverage reporting.",
      tags: ["Testing", "Python"],
      stack: ["Python", "pytest", "pytest-cov"],
      repo: "https://github.com/your-username/software-testing-demo",
      demo: ""
    },
    {
      title: "Personal Portfolio",
      description: "This responsive, accessible portfolio site with dark mode, deployed automatically to GitHub Pages.",
      tags: ["Web"],
      stack: ["HTML", "CSS", "JavaScript"],
      repo: "https://github.com/your-username/portfolio-website",
      demo: "https://your-username.github.io/portfolio-website/"
    },
    {
      title: "Your Next Project",
      description: "Describe the problem, what you built, and the result. Numbers and outcomes make projects stand out.",
      tags: ["Web", "Python"],
      stack: ["Add", "Your", "Stack"],
      repo: "",
      demo: ""
    }
  ],

  timeline: [
    {
      period: "2025 - Present",
      title: "Job Title, Company Name",
      text: "Key responsibilities and achievements. Example: automated 120 regression tests, cutting release testing time by 60%."
    },
    {
      period: "2024 - 2025",
      title: "Internship / Previous Role, Company",
      text: "What you worked on, tools you used, and what you delivered."
    },
    {
      period: "2020 - 2024",
      title: "B.Tech / B.Sc. in Computer Science, Your University",
      text: "Relevant coursework, honors, or final-year project."
    }
  ]
};
