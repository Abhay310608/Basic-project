# Personal Portfolio Website

A fast, responsive, accessible portfolio built with plain **HTML, CSS and JavaScript**. There is no framework
and no build step, so it deploys anywhere, including free on **GitHub Pages**.

## Features

- Responsive layout (mobile, tablet, desktop) with a mobile menu
- Dark / light theme (follows system preference, remembers the choice)
- Projects with tag filters, all driven from one data file
- Skills, experience/education timeline, contact form (opens the visitor's email app)
- Scroll animations, reduced-motion support, skip link, keyboard-friendly focus states
- SEO and social meta tags, SVG favicon
- Automatic deployment with GitHub Actions

## Customize in 5 minutes

1. **`js/data.js`**: edit your skills, projects, timeline and contact email.
2. **`index.html`**: replace `Your Name`, initials `YN`, tagline, About text, city, social links (search for `your-username`).
3. **`assets/`**: add `resume.pdf` (and optionally images/screenshots).
4. **`css/style.css`**: change brand colors in the `:root` block (`--primary`, `--accent`).

## Run locally

Just open `index.html` in a browser, or use a tiny server:

```bash
python -m http.server 8000     # then visit http://localhost:8000
```

## Deploy to GitHub Pages

1. Create a repo on GitHub (for a root URL like `https://<username>.github.io`, name it `<username>.github.io`).
2. Push this project:
   ```bash
   git init
   git add .
   git commit -m "Initial portfolio"
   git branch -M main
   git remote add origin https://github.com/<username>/<repo>.git
   git push -u origin main
   ```
3. In the repo go to **Settings → Pages → Build and deployment → Source: GitHub Actions**.
4. The included workflow (`.github/workflows/deploy.yml`) publishes your site on every push to `main`.
   The live URL appears in the **Actions** tab and under Settings → Pages.

*Alternative without Actions:* Settings → Pages → Source: **Deploy from a branch** → `main` / `(root)`.

## Structure

```
├── index.html
├── css/style.css
├── js/
│   ├── data.js        # your content (edit this)
│   └── main.js        # theme, nav, filters, animations, form
├── assets/            # favicon, résumé, images
└── .github/workflows/deploy.yml
```

## License

MIT. Use it freely for your own portfolio.
